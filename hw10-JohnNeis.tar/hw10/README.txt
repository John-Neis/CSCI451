NOTE: I've included a makefile. All you need to do to compile it is to type 
"make" in the terminal inside the directory